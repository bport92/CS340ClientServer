from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, USER, PASS):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        
        
        #USER = 'aacuser'
        #PASS = 'snhu1234' 
        
        
        HOST = 'localhost'
        PORT = 27017
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        print('connection good')

    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        try:
            self.database.animals.insert_one(data)  # data should be dictionary
            return True
        except Exception as e:
            return str(e)

# Create method to implement the R in CRUD.
    def read(self, query):
        try:
            results = self.database.animals.find(query) 
            return list(results)
        except Exception as e:
            return str(e)
        
# Creating a method to implement U in CRUD
    def update(self, query, update_data):
        try:
            result = self.collection.update_many(query, {'$set': update_data})
            return f"Modified {result.modified_count} data"
        except Exception as e:
            return str(e)

# Creating a method to implement D in CRUD
    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"Error reading: {e}")
            return False
             
            
            